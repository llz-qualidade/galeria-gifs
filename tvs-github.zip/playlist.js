// Gerado pelo Painel das TVs em 25/11/2026 12:00:00 — não edite à mão.
window.TV_PLAYLIST = {
  "versao": "2026-11-25T15:00:00.000Z",
  "geradoEm": "25/11/2026 12:00:00",
  "duracaoPadrao": 15,
  "intervaloVerificacao": 60,
  "ajuste": "cobrir",
  "itens": [
    {
      "arquivo": "5ª Cerimônia de Formatura.jpg",
      "titulo": "5ª Cerimônia de Formatura"
    },
    {
      "arquivo": "Nova semana, novas conquistas e bônus.png",
      "titulo": "Nova semana, novas conquistas e bônus"
    },
    {
      "arquivo": "Resultados diários de 05 a 09_10.png",
      "titulo": "Resultados diários de 05 a 09_10"
    },
    {
      "arquivo": "Parcial da semana_ rumo à meta (1).png",
      "titulo": "Parcial da semana_ rumo à meta (1)"
    },
    {
      "arquivo": "Resultados diários Todo Dia Tem Mais! (1).png",
      "titulo": "Resultados diários Todo Dia Tem Mais! (1)"
    },
    {
      "arquivo": "codigo.jpg",
      "titulo": "codigo"
    }
  ]
};
